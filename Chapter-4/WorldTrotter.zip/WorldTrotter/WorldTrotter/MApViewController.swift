//
//  MApViewController.swift
//  WorldTrotter
//
//  Created by Waleed Alassaf on 14/10/2020.
//

import UIKit

class MapViewController: UIViewController {
    
    
    override func viewDidLoad() {
        print("MapViewController loaded it self")
    }
    
    
}
