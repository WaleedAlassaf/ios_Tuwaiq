import Cocoa

// Array bronze challenge
var toDoList = ["Take out the trash", "pay bills" , "Cross off finished items"]
//From Dev Documentation
toDoList.isEmpty


// Array silver challenge

var toDoList_Reversed:Array<String?> = []

for i in 0..<toDoList.count{
    toDoList_Reversed.append(toDoList[toDoList.count - 1 - i])
}
print(toDoList_Reversed)

//Dev Documentation solution

toDoList.reverse()
print(toDoList)
