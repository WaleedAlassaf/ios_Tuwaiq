import Cocoa


// Listing 7.1 Hello, playground

let Str:String = "Hello world!"

//Listing 7.2 Creating a mutable string

var str = "hello world"

str.append("!!!")

print(str)


var breakLine = "this line will \nbreak"

print (breakLine)


// Listing 7.4 Using escape sequences in a string


let text1 = "I want to \"say\":\n\(str)"
print (text1)

//Listing 7.5 Creating a raw string

let rawStr = #"I want to \"say\":\n\(str)"#
print (rawStr)

//Listing 7.6 mutablePlayground’s Characters


for c: Character in text1{
    
    print(c)
    
    
}

//Listing 7.7 Using a Unicode scalar

let snowman = "\u{2603}"
print(snowman)

//Listing 7.8 Using a combining scalar

let aAcute = "\u{0061}\u{0301}"
let A = "\u{0061}"

//Listing 7.9 Revealing the Unicode scalars behind a string

for scalar in str.unicodeScalars {
    
    print("\(scalar.value)")
    
}

//Listing 7.10 Using a precomposed character

let aAcuteprecomposed = "\u{00E1}"

if (aAcute == aAcuteprecomposed) {
    print ("yes")
}

//Listing 7.12 Counting characters

aAcute.count
aAcuteprecomposed.count

//Listing 7.13 Finding the fifth character
// Listing 7.14 Pulling out a range
//Listing 7.15 Using a one-sided range

var Str713 = "hello world"
var start = Str713.startIndex
print (start)
var end = Str713.index(start, offsetBy: 6) //
let range = start...end
//let range = ...end
//let range = start...
//let range = start..<end
var wantedChar = Str713[range]

print (wantedChar)
