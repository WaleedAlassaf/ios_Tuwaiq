import Cocoa

// Silver Challenge chapter 6
var resultmsg = ""
for i in 1...100{
    
    if i % 3 == 0 {
        resultmsg.append("FIZZ, ")
    }
    else if i % 5 == 0 {
        resultmsg.append("BUZZ, ")
    }
    else if i % 5 == 0 && i % 3 == 0 {
        resultmsg.append("FIZZ BUZZ, ")
    }
    else {
        resultmsg.append("\(i), ")
    
    }
}
print (resultmsg)


