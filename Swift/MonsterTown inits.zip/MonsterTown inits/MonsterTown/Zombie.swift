//
//  Zombie.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation

class zombie: Monsters {
    
    var WalkWithLimp : Bool
    private(set) var isFallingApart: Bool
    func regenerat(){
        WalkWithLimp = false
    }
    override class var spookyNoise: String {
        
        return "Brains..."
    }
    
    required  init (Limp: Bool, isFallingApart: Bool, Town: Town? , monsterName: String ){
        
        WalkWithLimp = Limp
        self.isFallingApart = isFallingApart
        super.init(town: Town, name: monsterName)
        
    }
    convenience init(Limp: Bool, isFallingApart: Bool) {
        self.init(Limp: Limp, isFallingApart: isFallingApart, Town: nil, monsterName: "Fred")
        if WalkWithLimp {
            print("Zombie has a bad knees")
        }
    }
    
    deinit {
        print("\(MonsterName) is no longer with us")
    }
    
    
    required init(town: Town?, name: String) {
        fatalError("init(town:name:) has not been implemented")
    }
    override func terrorizeTown() {
        town?.changePopulation(by: -10)
        super.terrorizeTown() // we access the method in monster class here
        regenerat()
    }
    
}
