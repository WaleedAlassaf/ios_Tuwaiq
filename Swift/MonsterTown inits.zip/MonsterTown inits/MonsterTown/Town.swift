//
//  Town.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation


struct Town {
    static let world = "Earth"
    let region: String
    var population: Int
    var numberOfStopLights: Int
    
    init?(region: String, population: Int, numberOfStopLights : Int ){
        guard population > 0 else {
            print("guard nil")
            return nil
        }
        
        self.region = region
        self.population = population
        self.numberOfStopLights = numberOfStopLights
    }
    
    init?(population: Int, numberOfStopLights: Int) {
        self.init(region: "N/A", population: population, numberOfStopLights: numberOfStopLights)
    }

    
    func description (){
        
        print("We have \(population) population in our town, \(numberOfStopLights) stop lights, we're \(region)")
        
    
    }
    
    mutating func changePopulation(by amount: Int){
            
        population += amount
            
        
    }
}


