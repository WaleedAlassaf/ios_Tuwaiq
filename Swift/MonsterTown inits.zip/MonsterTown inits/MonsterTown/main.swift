//
//  main.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation


var myTown = Town(population: 0, numberOfStopLights: 8)
myTown?.description()
var FredTheZombie: zombie? = zombie(Limp: true, isFallingApart: false, Town: myTown, monsterName: "Fred")
print(FredTheZombie?.MonsterName)
FredTheZombie = nil
var convenienceZombie = zombie(Limp: true, isFallingApart: true)

