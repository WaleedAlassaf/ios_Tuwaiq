import Cocoa

// Protocals Gold challenge + Silver challenge + Bronze challenge

protocol TabulstDataSource {
    
    var numberOfRows:Int {get}
    var numberOfColumns:Int {get}
    func Lable(ForColumns column: Int) -> String
    func itemFor(row: Int, column: Int) -> String
    
}


func PrintTable (_ dataSource:TabulstDataSource ){
    var headerRow = "|"
    var columeWidth = [Int]()
    
    
    //gold challenge + bronze challenge
    func ExtraPadding (_ colLength: Int) -> Int {
        var longest: Int = 0
        var count = 0
        for i in count ..< dataSource.numberOfRows {
            for j in 0..<dataSource.numberOfColumns{
                let item = dataSource.itemFor(row: i, column: j)
                longest = max(colLength, item.count, longest)
            }
        }
        if longest > colLength{
            count += 1
            return longest
        }else{
            count += 1
            return colLength
        }
    }
    
    
    
    
    for i in 0..<dataSource.numberOfColumns {

        let columeLable = dataSource.Lable(ForColumns: i)
        let columePadding = ExtraPadding(columeLable.count)
        columeWidth.append(columePadding)
        // multiply by -1 so the negative value become positive
        var numberOFPaddingNeededForColume = (columeLable.count - columePadding) * -1
        // change the number of padding needed for the column to an actual spaces
        var columepad = repeatElement(" ", count: numberOFPaddingNeededForColume ).joined(separator: "")

        let columeHeader = "\(columepad)\(columeLable) |"
        headerRow += columeHeader
    }
    print(headerRow)
    
    
    for i in 0 ..< dataSource.numberOfRows{
        
        var out = "|"
        
        for j in 0..<dataSource.numberOfColumns {
            let item = dataSource.itemFor(row: i, column: j)
            var PaddingNeeded = columeWidth[j] - item.count
            if PaddingNeeded < 0{
                PaddingNeeded = 0
                
            }
            let padding = repeatElement(" ", count: PaddingNeeded ).joined(separator: "")
                out += " \(padding)\(item)|"
            
        }
        print(out)
        }
    }

struct Person {
    let name : String
    let age: Int
    let YearsOfExp: Int
}

struct Department: TabulstDataSource { //, CustomStringConvertible {
    
    let name: String
    var people = [Person]()
    var description: String{
        return "Department : \(name)"
        
    }
    init (name: String){
        self.name = name
    }
    mutating func AddPerson (_ person: Person){
        people.append(person)
        //print(People)
    }
    var numberOfRows: Int {
        return people.count
    }
    var numberOfColumns: Int{
        return 3
    }
    func Lable(ForColumns column: Int) -> String {
        switch column {
            case 0:
                return "Employee Name"
            case 1:
                return "Age"
            case 2:
                return "Years of experience"
            default:
                fatalError("Invalid Column")
        }
    }
    func itemFor(row: Int, column: Int) -> String {
        let person = people[row]
        switch column{
            case 0:
                return person.name
            case 1:
                return String(person.age)
            case 2:
                return String(person.YearsOfExp)
            default:
                fatalError("Invalid Column")
                
            
        }
    }
}

var department = Department(name: "Engineering")
department.AddPerson(Person(name: "Eva", age: 10000000, YearsOfExp: 5))
department.AddPerson(Person(name: "Ali", age: 32, YearsOfExp: 8))
department.AddPerson(Person(name: "Ahmed", age: 24, YearsOfExp: 3))
PrintTable(department)


struct BookInfo {
    
    let Auther: String
    let bookName: String
    let Rating: Int
    
}

struct BookCollection: TabulstDataSource{
   
    var authers = [BookInfo]()
    
    
    var numberOfRows: Int{
        return authers.count
    }
    var numberOfColumns: Int{
        return 3
    }
    mutating func AddBook (_ Book: BookInfo){
        authers.append(Book)
    }
    
    func Lable(ForColumns column: Int) -> String {
        switch column {
            case 0:
                return "Book Name"
            case 1:
                return "Auther"
            case 2:
                return "Rating"
            default:
                fatalError("Invalid Column")

        }
    }
    
    func itemFor(row: Int, column: Int) -> String {
        let books = authers[row]
        switch column{
            case 0:
                return books.Auther
            case 1:
                return books.bookName
            case 2:
                return String(books.Rating)
            default:
                fatalError("Invalid Column")
                
            
        }}
}
print("")
print("")
print("")
var library = BookCollection()
library.AddBook(BookInfo(Auther: "Alex", bookName: "Book 10000", Rating: 9))
library.AddBook(BookInfo(Auther: "Steven", bookName: "Book 2", Rating: 10))
library.AddBook(BookInfo(Auther: "Safanh", bookName: "Book 3", Rating: 10))
PrintTable(library)
