//
//  Asset.swift
//  Memory_Managment
//
//  Created by Waleed Alassaf on 11/10/2020.
//

import Foundation

extension Asset: CustomStringConvertible {
    
    var description: String{
        
        if let container = container{
            return "Asset \(name), worth \(value), in container \(container)"
        }else{
            return "Asset \(name), worth \(value), not stored anywhere"
        }
    }
}



class Asset {
    let name: String
    //let value: Double
    var value:Double {
        
        didSet{
            
            changeHandler(value - oldValue)
        }
        
    }
    weak var container: Valut?
    
    typealias ValueChangeHandler = (Double) -> Void
    var changeHandler: ValueChangeHandler //= {_ in}
    
    init(name: String, value: Double, changeHandler: @escaping ValueChangeHandler = {_ in}) {
        self.name = name
        self.value = value
        self.changeHandler = changeHandler
    }
    
    deinit {
        print("\(self) is being dealocated")
    }
}

