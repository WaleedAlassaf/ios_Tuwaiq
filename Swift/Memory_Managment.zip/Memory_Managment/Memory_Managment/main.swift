//
//  main.swift
//  Memory_Managment
//
//  Created by Waleed Alassaf on 11/10/2020.
//

import Foundation

class Valut {
    
    let number: Int
    
    private(set) var assets = [Asset]()
    
    var totalValue:Double = 0
    #warning("total value shoud be computed value")
    
    init(number: Int) {
        self.number = number
    }
    deinit {
        print("\(self) is dealocating")
    }
    func store(_ asset: Asset){
        
        asset.container = self
        asset.changeHandler = { [weak self] (change) in
            //print("An asset has change value by \(change). new total value \(self.totalValue)")
            print("New total value: \(String(describing: self?.totalValue))")
        }
        assets.append(asset)
        
        
    }
}

extension Valut: CustomStringConvertible{
    
    var description: String{
        
        return "Vault (\(number))"
    }
}

class Simulation{
    
    func run(){
        
        let valut13 = Valut(number: 13)
        print("\(valut13) was created")
        
        let coin: Asset = Asset(name: "Rare coin", value: 1_000)
        let gem: Asset = Asset(name: "Big diamond", value: 5_000)
        let poem: Asset = Asset(name: "Magnum ops", value: 0.0)
        
        valut13.store(coin)
        valut13.store(gem)
        
        print("created some gems \([coin, gem, poem])")
        coin.value += 137
    }
    
}

let simulation = Simulation()
simulation.run()
dispatchMain()

