import Cocoa

enum token: CustomStringConvertible {
    
    case number(Int)
    case plus
    
    var description: String {
        switch self{
            case .number(let n):
                return "Number: \(n)"
            case .plus:
                return "Symbol: +"
        }
    }
}

class Lexer {
    enum Error: Swift.Error {
        case InvalidChar(Character)
    }
    
    let input: String
    var position: String.Index
    
    init(input: String) {
        self.input = input
        self.position = input.startIndex
    }
    func peek() -> Character? {
        
        guard position < input.endIndex else {
            return nil
        }
        return input[position]
    }
    func advance(){
        assert(position < input.endIndex, "Cant go past end index!")
        position = input.index(after: position)
    }
    
    func getNumber()->Int {
        var value = 0
        while let nextCharacter = peek() {
            switch nextCharacter{
                case "0"..."9":
                    let digitalValue = Int(String(nextCharacter))!
                    value = 10 * value + digitalValue
                    advance()
                default:
                    return value
            }
        }
        return value
        
    }
    func lex() throws -> [token] {
        
        var tokens = [token]()
        while let nextChar = peek() {
            switch nextChar {
                case "0"..."9":
                    let value = getNumber()
                    tokens.append(.number(value))
                case "+":
                    tokens.append(.plus)
                    advance()
                case " ":
                    advance()
                default:
                    throw Lexer.Error.InvalidChar(nextChar)
            }
        }
        return tokens
    }
}

class Parser {
    
    enum Error: Swift.Error {
        
        case UnexpectedEndOfInput
        case invalidToken(token)
        
    }
    
    let tokens: [token]
    var position = 0
    
    init(tokens: [token]) {
        self.tokens = tokens
    }
    
    func getNextToken() -> token? {
        guard position < tokens.count else {
            return nil
        }
        let token = tokens[position]
        position += 1
        return token
    }
    func getNumber() throws -> Int{
        
        guard let token = getNextToken() else {
            throw Parser.Error.UnexpectedEndOfInput
        }
        switch token{
            case .number(let value):
                return value
            case .plus:
                throw Parser.Error.invalidToken(token)
        }
    }
    func parse() throws -> Int{
        
        var value = try getNumber()
        
        while let token = getNextToken(){
            switch token{
                
                case .plus:
                    let nextNumber = try getNumber()
                    value += nextNumber
                case .number:
                    throw Parser.Error.invalidToken(token)
            }
        }
        return value
    }
}


func evaluate (_ input: String) {
    print("Evaluating \(input)")
    let mylexer = Lexer(input: input)
//    guard let tokens = try? mylexer.lex() else{
//        print("Lexer failed, I don't know why")
//        return
//    }
    do{
        //let tokens = try mylexer.lex()
        let tokens = try mylexer.lex()
        print("Lexer output: \(tokens)")
        
        let parser = Parser(tokens: tokens)
        let result = try parser.parse()
        print("Parse output: \(result)")
        
    }catch Parser.Error.UnexpectedEndOfInput {
        print("Unexpected end of input during parsing")
    }catch Parser.Error.invalidToken(let token){
        print("invalid token during parsing \(token)")
    }catch Lexer.Error.InvalidChar(let char){
        print("Invalid \(char)")
    }catch{
        print("An error occured \(error)")
    }
}


evaluate("10 + 5 + 3")
evaluate("10 + 5 + three")
