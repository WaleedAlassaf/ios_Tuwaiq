import Cocoa

//Listing 9.1 Declaring an optional instance

var errorCode: Optional<String>
errorCode = Optional("404")

//Listing 9.2 Using shorthand optional syntax
//Listing 9.3 Logging the value of the optional to the console
//Listing 9.4 Logging the nil value of the optional to the console

var errorCode2 :String?
errorCode2 = "404"
print(errorCode2)


//Listing 9.5 Adding a condition

if errorCode2 != nil {
    
    let theError = errorCode2
    print(theError)
}

//Listing 9.6 Optional binding

if let theError2 = errorCode2 { // if errorCode2 is nill the if statment will not work.
    print("not nil")
    
}


//Listing 9.7 Nesting optional binding

var errorCode97:String? = "500"

if let a = errorCode97 {
    //intError is stored as int
    if let intError = Int(a){
        print("\(intError) ..  \(a)")
        
    }
    
}


//Listing 9.8 Unwrapping multiple optionals
//Listing 9.11 Modifying in place
//Listing 9.10 Optional chaining


//this gave the same result of 9.7 but without nesting
var description :String?
if let x = errorCode97, let intError2 = Int(x){
    print("\(intError2) ..  \(x)")
    description = "\(intError2 + 200) resourse not found"
    
}
var uppercaseDes = description?.uppercased()
uppercaseDes?.append(" try again")
print(uppercaseDes)

var msg :String

if let uppercaseDes = uppercaseDes {
    
    msg = uppercaseDes
    print(msg + " im msg")
    
}
else {
    print("no error")
    
}


//Listing 9.9 Optional binding and additional checks
if let y = errorCode97, let intError3 = Int(y), intError3 == 500 {
    
    print("listing 9.9")
    
}

var empty: String! = nil
//var equal2empty:String = empty
var thirdempty = empty
print(empty)
//print(equal2empty)
print(thirdempty)


//Listing 9.13 Using the nil coalescing operator
// the element after the ?? is default if there is a nil
uppercaseDes = nil
let des = uppercaseDes ?? "no error"

print(des)
