import Cocoa

//Sets Challenge: bronze

var myCities: Set = ["Tokyo","Alriyadh","newyork","Alrass"]
var YourCities: Set = ["Tokyo","Alriyadh"]


if YourCities.count < myCities.count {
    if YourCities.isSubset(of: myCities){
        print("I've also went to all the cities you traveld to! which are \(YourCities)")
    }
}
else if YourCities.count > myCities.count {
    if myCities.isSubset(of: YourCities) {
        print ("You went to all the cities I've been to! which are \(myCities)")
    }
}


//Sets challenge : Silver

var UnionSet :Set = ["waleed", "Ali", "Ahmed", "sarah", "sarah"]
var UnionSet2 : Set = ["mohanad", "Saleh", "yaser", "Saleh"]
//print (UnionSet.union(UnionSet2))
let Union_Array2 = Array(UnionSet2)

for People in 0..<UnionSet2.count {
    
    if UnionSet.contains(Union_Array2[People]){
        print("pass")
    }else {
        UnionSet.insert(Union_Array2[People])
    }
}
print (UnionSet)



var Set1: Set = ["Alriyadh", "Alrass", "Tokyo", "New york"]
var Set2_Intersection :Set = ["Tokyo", "Albadya", "New york", "Dubai"]

var Arr2 = Array(Set2_Intersection)

for cities in 0 ..< Set1.count {
    
    if Set1.contains(Arr2[cities]){
        print("Pass")
    }
    else {
        Set2_Intersection.remove(Arr2[cities])
    }
}
print(Set2_Intersection)
