import Cocoa


// bronze challenge : optinals

//A person’s age: Int or Int?
// we choose Int because person's age cant be a nil

//• A person’s middle name: String or String?
// we choose String because everyone have a middle name it cant be a nil

//• A person’s kids’ names: [String] or [String]? or [String?]
// we choose String because kid has a name

//silver challenge
var Crash :String? = nil

//print (Crash!)

//Fatal error: Unexpectedly found nil while unwrapping an Optional value: file __lldb_expr_7/optinal_Challenges.playground, line 18

// gold challeng

var bucketList = ["Climb Mt. Everest, Read War and Peace", "Go on an Arctic expedition", "Scuba dive in the Great Blue Hole", "Find a triple rainbow"]

let i = bucketList.firstIndex(of: "Go on an Arctic expedition")
var Next_two_in_the_array = i!
bucketList[Next_two_in_the_array + 2]
