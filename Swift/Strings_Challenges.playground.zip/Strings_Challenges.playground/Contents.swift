import Cocoa
//Bronze challenge Strings

let empty = ""
//empty.isEmpty
//if the index of the x is equal to the index of y that means its empty
var x = empty.startIndex
var y = empty.endIndex

if x == y {
    
    print("this var is empty")
}



//Silver Challenge Strings

var str = "hello"

var unicodeStr = "\u{0068}\u{0061}\u{006C}\u{006C}\u{006F}"
print (unicodeStr)
