import Cocoa

//bronze challenge

var list1 = [1,56, 12, 11, 78, 109, 42, 17]

list1.sort { $0 < $1}

print (list1)


// silver challenge

var list2 = [1,56, 12, 11, 78, 109, 42, 17]
print(list2.sorted(by: <))


// gold challenge

var volunteerAvrg = [23.4, 32.2, 10.2, 9.4, 1.2, 4.5]

var solution = volunteerAvrg.map { Int($0.rounded())}.filter{ $0 >= 10}.reduce(5) {$0 + $1}

print(solution)
