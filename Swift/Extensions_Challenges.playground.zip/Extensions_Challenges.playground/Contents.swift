import Cocoa


// Bronze Challenge

struct Department {
    
    var description: String{
        return "Department."
        
    }
}

extension Department: CustomStringConvertible {
    
}


// silver challenge

extension Int {
    enum OddEven {
        case even
        case odd
    }
    var MyNum: OddEven {
        
        switch self % 2 == 0{
            case true:
                return .even
            case false:
                return .odd
        
        }
    }
}
var num: Int = 2

num.MyNum
