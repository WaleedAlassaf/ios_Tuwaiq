import Cocoa
//value semantic : copy of the value
var str = "hello world"
var playground = str

str = "goodbye world"
print(str)
print(playground)


playground += ", how's your day? "
print(playground)


//Refrence semantic : the value itself
class employee {
    
    var id = 0
    
}

let ali = employee()
let TheBoss = ali

ali.id = 71
ali.id
TheBoss.id

struct Company {
    
    var Boss: employee
    
}

let acme = Company(Boss: ali)
var mel = employee()
mel.id = 90 //Im able to change this id because id is a var not a let
mel.id
ali.id

acme.Boss.id
let widgetCo = acme
ali.id = 70
widgetCo.Boss.id

let juampa = employee()

let emplyees = [ali, mel, juampa]
let emplyeesCopy = emplyees
emplyees.last?.id = 4
emplyees
emplyeesCopy

acme.Boss === ali

let joe = employee()
let sam = employee()

joe === sam

//var x = 7
//var y = x
//
//x === y

