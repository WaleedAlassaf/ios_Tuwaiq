import Cocoa

var str = ""

for _ in 1...50_000{
    
    str.append("a")
    
}

let currentDate = Date()
print(currentDate)

str.count

let newCurrentDate = Date()
let timeCount = newCurrentDate.timeIntervalSince(currentDate)
print(timeCount)

//Q1: the larger the string count the slower it becomes

//Q2: I think its because every element in that string is stored in a different place in the memory so the larger the string the longer it takes to fitch every bit of that string
