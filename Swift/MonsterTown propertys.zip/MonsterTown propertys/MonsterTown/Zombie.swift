//
//  Zombie.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation

class zombie: Monsters {
    override class var makeSpookySounds: String {
        return "Brains..."
    }
    var WalkWithLimp = true
    private(set) var isFallingApart = false
    func regenerat(){
        WalkWithLimp = false
        
        
    }
    override func terrorizeTown() {
        if !isFallingApart {
            town?.changePopulation(by: -10)}
        super.terrorizeTown() // we access the method in monster class here
        regenerat()
    }
    
}
