//
//  main.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation

var myTown = Town()

print("")
myTown.description()
let myTownSize = myTown.townSize
print(myTownSize)
myTown.changePopulation(by: 1)
myTown.description()
print("population = \(myTown.townSize)")

var FredTheZombie = zombie()
FredTheZombie.name = "Fred"
FredTheZombie.town = myTown

print(FredTheZombie.victimPool)
FredTheZombie.victimPool = 500
print("victim pool = \(FredTheZombie.victimPool)")
print(zombie.makeSpookySounds)

print(zombie.isTerrifying)
print(Monsters.isTerrifying)

if zombie.isTerrifying == true {
    
    print("hello terrifing zombie..")
    
}
print(FredTheZombie.isFallingApart)
