import Cocoa

enum ProgrammingLanguage: String, CaseIterable {
    
    case swift
    case ObjectiveC
    case c
    case cPP
    case java
}


for i in ProgrammingLanguage.allCases{
    print(i)
}

print("")

print(ProgrammingLanguage.allCases.map({"\($0)"}).joined(separator: ", "))
