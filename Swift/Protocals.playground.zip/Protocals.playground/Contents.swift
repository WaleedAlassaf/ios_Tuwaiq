import Cocoa

protocol TabulstDataSource { //: CustomStringConvertible {
    
    var numberOfRows:Int {get}
    var numberOfColumns:Int {get}
    func Lable(ForColumns column: Int) -> String
    func itemFor(row: Int, column: Int) -> String
    
}


//func PrintTable (_ data: [[String]], WithColumeLabels columeLables: [String]){
func PrintTable (_ dataSource:TabulstDataSource ){//& CustomStringConvertible){
    var headerRow = "|"
    var columeWidth = [Int]()
    //for item in columeLables {
    for i in 0..<dataSource.numberOfColumns {

        let columeLable = dataSource.Lable(ForColumns: i)
        let columeHeader = "\(columeLable) |"
        headerRow += columeHeader
        columeWidth.append(columeLable.count)
    }
    print(headerRow)
    
    //for row in data {
    for i in 0 ..< dataSource.numberOfRows{
        var out = "|"
//        for item in row {
//            out += "\(item) |"
        //for (j, item) in row.enumerated(){
        for j in 0..<dataSource.numberOfColumns{
            let item = dataSource.itemFor(row: i, column: j)
            let PaddingNeeded = columeWidth[j] - item.count
            let padding = repeatElement(" ", count: PaddingNeeded).joined(separator: "")
            out += " \(padding)\(item) |"
            
        }
        print(out)
        
        }
    }


//var myArr = [
//    ["a","b","c"],["1","2","3"], ["QQ","VV","EE"]
//
//]
//
//NestedArr(myArr, WithColumeLabels: ["Emplyee Name", "Age", "Years of experince"])


struct Person {
    let name : String
    let age: Int
    let YearsOfExp: Int
}

struct Department: TabulstDataSource { //, CustomStringConvertible {
    
    let name: String
    var people = [Person]()
    var description: String{
        return "Department : \(name)"
        
    }
    init (name: String){
        self.name = name
    }
    mutating func AddPerson (_ person: Person){
        people.append(person)
        //print(People)
    }
    var numberOfRows: Int {
        return people.count
    }
    var numberOfColumns: Int{
        return 3
    }
    func Lable(ForColumns column: Int) -> String {
        switch column {
            case 0:
                return "Employee Name"
            case 1:
                return "Age"
            case 2:
                return "Years of experience"
            default:
                fatalError("Invalid Column")
        }
    }
    func itemFor(row: Int, column: Int) -> String {
        let person = people[row]
        switch column{
            case 0:
                return person.name
            case 1:
                return String(person.age)
            case 2:
                return String(person.YearsOfExp)
            default:
                fatalError("Invalid Column")
                
            
        }
    }
}

var department = Department(name: "Engineering")
department.AddPerson(Person(name: "Eva", age: 29, YearsOfExp: 5))
department.AddPerson(Person(name: "Ali", age: 32, YearsOfExp: 8))
department.AddPerson(Person(name: "Ahmed", age: 24, YearsOfExp: 3))
PrintTable(department)
print(department)

let operationDataSourse: TabulstDataSource = Department(name: "Operations")
print(operationDataSourse)
let EngineeringOperation = department as TabulstDataSource
let Mikey = Person(name: "Mikey", age: 37, YearsOfExp: 10)
Mikey is TabulstDataSource



class PersonClass {
    var name : String = ""
    var age: Int = 0
    var YearsOfExp: Int = 0
    init(PersonName: String, PersonAge: Int, YearsOfExp: Int ) {
        
    }

}

class EmplyeeClass: PersonClass, CustomStringConvertible {
    var EmplyeeID: Int = 0
    
    init(_ ID: Int, name: String, age: Int, YearsOfExp: Int) {
        EmplyeeID = ID
        super.init(PersonName: name, PersonAge: age, YearsOfExp: YearsOfExp)
    }
    var description: String{
        return "Name: \(name) age: \(age) ID: \(EmplyeeID)"
    }
}
func printResource(_ resourse: PersonClass ){//& CustomStringConvertible){
    
    print("Resourse: \(resourse)")
    
}


