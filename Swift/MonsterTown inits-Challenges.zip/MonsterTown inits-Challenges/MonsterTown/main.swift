//
//  main.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation


var myTown = Town(population: 0, numberOfStopLights: 8)


myTown?.description()
var FredTheZombie = zombie(Limp: true, isFallingApart: true, Town: myTown, monsterName: "Fred")

print(FredTheZombie?.MonsterName)

//FredTheZombie = nil
var convenienceZombie = zombie(Limp: true, isFallingApart: true)

var newZombie = zombie(town: myTown, name: "zombieQ")
