//
//  Monster.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation

class Monsters {
    
    var town: Town?
    var MonsterName : String = ""
    class var spookyNoise: String {
        
        return "3ww..."
    }
    //Gold challenge
    init?(town: Town?, name: String) {
        self.town = town
        guard name != "" else {
            return nil
        }
        MonsterName = name
    }
    //-----------------------------
    func terrorizeTown (){
        
        if town != nil {
            
            print("\(MonsterName) is terrorizing the town")
            
        }else {
            
            print("\(MonsterName) hasn't found any towns")
     
        }
    }
}
