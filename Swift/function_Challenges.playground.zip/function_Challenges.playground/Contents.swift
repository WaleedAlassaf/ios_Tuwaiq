import Cocoa


//Bronze Challenge


func greetMiddleName (_ Fullname: (first: String, middle:String?, last: String)){
    
    guard let middleName = Fullname.middle, Fullname.middle?.count ?? 0 >= 10 else {
        print("hi")
        return
    }
    var firstletterStart = Fullname.middle!.startIndex
    var firstletter = Fullname.middle!.index(firstletterStart, offsetBy: 0)
    
    print("Hi \(Fullname.first) \(Fullname.middle![firstletter]) \(Fullname.last)")
}
greetMiddleName(("waleed", "Aaaaaaaaaa", "Alassaf"))



func siftbean (_ GroceryList: [String]) -> ([String], [String]){
    var beans:[String] = []
    var others: [String] = []
    
    
    for item in GroceryList{
        
        if item.hasSuffix("beans"){
            beans.append(item)
            
        }else {
            others.append(item)
        }
        
    }
    let grocery = (beans, others)
    return grocery
    
}

var myGrocery = ["green beans", "milk", "pinto beans", "chicken", "choclate", "beans"]


var beansAndotherGrocery = siftbean(myGrocery)
print(beansAndotherGrocery)
