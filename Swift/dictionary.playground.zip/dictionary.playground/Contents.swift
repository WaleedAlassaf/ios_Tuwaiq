import Cocoa


var myDictionary = ["waleed": 10, "ali": 11, "sultan": 20]

print(myDictionary["waleed"])

//Listing 10.2 Using count
myDictionary.count

//Listing 10.4 Modifying a value
myDictionary["waleed"] = 19
print(myDictionary)

let oldDictionary: Int? = myDictionary.updateValue(20, forKey: "sultan1")
print(myDictionary)

//Listing 10.6 Adding a value

myDictionary["saleh"] = 100
print(myDictionary)

//Listing 10.7 Removing a value
myDictionary.removeValue(forKey: "ali")
print(myDictionary)

//Listing 10.8 Setting the key’s value to nil

myDictionary["sultan1"] = nil

//Listing 10.9 Looping through your dictionary

for (name, ID) in myDictionary{
    
    print("\(name)..\(ID)")
}
print("")
//Listing 10.10 Accessing just the keys

for names in myDictionary.keys {
    
    print("\(names)")
}

//Listing 10.11 Making the dictionary immutable
let myDictionary2 = ["waleed": 10, "ali": 11, "sultan": 20]


//Listing 10.13 Sending keys to an array

let dictionary_To_Array = Array(myDictionary.keys)
print(dictionary_To_Array)
