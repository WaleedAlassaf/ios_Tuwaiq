import Cocoa

var list1 = [1,56, 12, 11, 78, 109, 42, 17]
//13.2

func isAscending (_ i :Int, _ j: Int) -> Bool{
    
    return i > j
}
let sortmylist = list1.sorted(by: isAscending)
print(sortmylist)

//13.3

let sortmylist_short = list1.sorted(by: { (i:Int, j:Int)->Bool in
                                            return i > j})
print(sortmylist_short)

//13.4

let sortmylist_short2 = list1.sorted(by: { i, j in i > j})
print(sortmylist_short2)

//13.5

let sortmylist_short3 = list1.sorted(by: {$0 > $1})
print(sortmylist_short3)

//13.6


let sortmylist_short4 = list1.sorted {$0 > $1}
print(sortmylist_short4)

//13.7 / 8 / 9 / 10 / 11 / 12 / 13/ 14 / 15

var listofDoubles = [10.2, 30.2, 3.4, 6.7]
// {"\($0)"}) is taking the first argument and passing it
func format (numbers: [Double], using formatter: (Double) -> String = {"\($0)"}) -> [String] {
    
    var result = [String]()
    for number in numbers {
        let transformed = formatter(number)
        result.append(transformed)
        
    }
    return result
}
func experimentWithScope(){
    var numberOftransformation = 0
    let rounder: (Double) -> String = {
        (num: Double) -> String in
        numberOftransformation += 1
        return "\(Int (num.rounded()))" //we used int here to remove the decimal zeros

}
    var listofDoubles = [10, 8.2, 9.4, 10.7]
    // calling a closure as a func parameter
    print(format(numbers: listofDoubles, using: rounder))
    print(format(numbers: listofDoubles))
    print(numberOftransformation)
}
experimentWithScope()
var dd = 3.3
Int(dd.rounded())


//13.17

let roundedAvrg = listofDoubles.map { (avg: Double) -> Int in
    return Int(avg.rounded()) }

let passingAvg = roundedAvrg.filter {(avg : Int) -> Bool in
    return avg >= 10
}
print(passingAvg)

let estimatedParticipation = passingAvg.reduce(0) {
    (estimatedSofar: Int, currentOrgAvg: Int) -> Int in
    return estimatedSofar + currentOrgAvg
    
}
