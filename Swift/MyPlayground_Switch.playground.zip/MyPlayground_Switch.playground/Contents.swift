import Cocoa
// First switch
var int = 97
var Massage = ""
switch int {

case 95:
    Massage = "Error number 1"
case 96:
    Massage = "Error number 2"
case 97:
    Massage = "Error number 3"
case 100:
    Massage = "This is correct"
default:
    print("none")
}
print(Massage)

//switch cases can have multiple values

switch int {

case 95, 96, 97:
    Massage += ", There was something wrong"
    print (Massage)
    fallthrough
default:
    print("please try again")

}
//Cases can match ranges of values

var age = 17

switch age{

case 0..<18:
    print("\(age) is too young")
case 18..<25:
    print("\(age) You're old enough")
case 25..<40:
    print("You're in")
default:
    print("Something is wrong")

}
//Using value binding

var ErrorStr = ""
var StatusCode = 490

switch StatusCode{

case 400...420:
    ErrorStr = "Error \(StatusCode)"
    print(ErrorStr)
case 421...450:
    ErrorStr = "Error \(StatusCode)"
    print(ErrorStr)
case let code:
    ErrorStr = "\(code) Unexpected error"
    print(ErrorStr)
    

}
//Using where to create a filter


var StatusCode1 = 602
var errorMassage = ""

switch StatusCode1{

case 400:
    errorMassage = "\(StatusCode1) Error1"
    print(errorMassage)
case 401..<420:
    errorMassage = "\(StatusCode1) Error2"
    print(errorMassage)
case 500..<505:
    errorMassage = "\(StatusCode1) Error3"
    print(errorMassage)
case let code1 where code1 < 100 || code1 >= 600: //every number higher than 600 or lower than 100
    errorMassage = "\(code1) is illegal status"
    print(errorMassage)
default:
    errorMassage = "\(StatusCode1) is unknown" // anything else
    print(errorMassage)

}


//Creating a tuple


var StatusCode2 = 400
var ErrorStr2 = "Error 2"
let error = (StatusCode2, ErrorStr2)
print (error)

print(error.1)
print(error.0)

//Naming the tuple’s elements

var StatusCode3 = 400
var ErrorStr3 = "Error 2"
let error2 = (code: StatusCode2, msg: ErrorStr2)
print (error2)

print(error2.code)
print(error2.msg)

//Pattern matching in tuples

var CodeNumber1 = 404
var CodeNumber2 = 100
let GroupCode = (CodeNumber1, CodeNumber2)
switch GroupCode{

case (404, 404):
    print ("Both codes have 404")
case (404, _):
    print ("First code is 404, the second one is unknown")
case (_ , 404):
    print("Second code is 404, the first one is unknown")
default:
    break


}


var age1 = 26
//if age is between 18 and 35 and age is higher than or equal 25 do the code
if case 18...35 = age1, age1 >= 25{
    
    print("pass")
    
}


//switch Bronze Challenge
//the first case would be selected because x is larger than 0 and y is also higher than 0

let point = (x: 1, y: 4)
switch point {
case let q1 where (point.x > 0) && (point.y > 0):
    print("\(q1) is in quadrant 1")
case let q2 where (point.x < 0) && point.y > 0:
    print("\(q2) is in quadrant 2")
case let q3 where (point.x < 0) && point.y < 0:
    print("\(q3) is in quadrant 3")
case let q4 where (point.x > 0) && point.y < 0:
    print("\(q4) is in quadrant 4")
case (_, 0):
    print("\(point) sits on the x-axis")
case (0, _):
    print("\(point) sits on the y-axis")
default:
    print("Case not covered.") }


//Silver Challenge

var age3 = 29
//if the age is between 18 and 35 and age is higher than 25 and age is lower than 30 do the code
if case 18...35 = age3, age3 >= 25, age3 < 30 {
    print("In cool demographic and can rent a car") }
