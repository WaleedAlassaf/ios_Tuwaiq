import Cocoa

extension Double {
    var squared: Double { return self * self }
}


var MySquare: Double = 10.1
MySquare.squared

struct car {
    
    var make: String
    var model: String
    let year: Int
    var fuelLevel: Double {
        willSet{
            precondition(newValue <= 1.0 && newValue >= 0.0,
                         "New Value Must be between 0.0 and 1.0")
            
        }
    }
    
}



let firstCar = car(make: "Benz", model: "Patent-Motorwagon", year: 1886, fuelLevel: 0.5)


extension car: CustomStringConvertible {
    var description: String{
        
     return "\(year) \(make) \(model) \(fuelLevel)"
        
    }
}

extension car {
    
    init( make: String, model: String, year: Int) {
        self.init(make: make, model: model, year: year, fuelLevel: 0.1)
    }
    
    
}

print(firstCar.description)

var myCar2 = car(make: "a", model: "b", year: 2010)

print(myCar2.description)

extension car {
    
    enum Era {
        case Vintage
        case Brass
        case Veteren
        case Modren
    }
    var Era: Era{
        switch year {
                case ...1896:
                    return .Veteren
                case 1896...1919:
                    return .Brass
                case 1920...1930:
                    return .Vintage
                default:
                    return .Modren
            }
    }
}
