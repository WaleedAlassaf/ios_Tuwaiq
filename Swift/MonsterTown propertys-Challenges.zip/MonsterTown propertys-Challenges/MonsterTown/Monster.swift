//
//  Monster.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation

class Monsters {
    static var isTerrifying = true
    
    class var makeSpookySounds: String {
        return "3ww..."
    }
    var town: Town?
    var name = "Monster"
    var victimPool: Int {
        get{
           return town?.population ?? 0
            
        }set (newVictimPool){
            
            town?.population = newVictimPool
            
        }
    }
    func terrorizeTown (){
        
        if town != nil {
            print("\(name) is terrorizing the town")
        }else {
            print("\(name) hasn't found any towns")
        }
    }
}
