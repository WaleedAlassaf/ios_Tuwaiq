//
//  Mayor.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 06/10/2020.
//

import Foundation

struct Mayor {
// gold challenge
    private var anxietyLevel = 0
    mutating func MayorMsg (){
        
        print("I'm deeply saddened to hear about this lately tragedy")
        anxietyLevel += 5
        print(anxietyLevel)
    }
    
    
}
