//
//  main.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation

var myTown = Town()
print("")
myTown.description()
let myTownSize = myTown.townSize
myTown.changePopulation(by: -100)


//print(Mayor.anxietyLevel) -- 'anxietyLevel' is inaccessible due to 'private' protection level
