//
//  Town.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation


struct Town {
    
    static let world = "Earth"
    let region = "middle"
   
    
    var MayorA = Mayor()
    var population = 5_000 {
       //Bronze Challenge + silver
        willSet{
            if newValue > population{
                print("The population changed to \(population) from \(newValue)")
            }
        }didSet { print("To the mayor: we lost \(oldValue - population) person today")
            MayorA.MayorMsg()   }
    }
    
    
    
    
    
    //----------------------
    var numberOfStopLights = 4
    
    enum size {
        case small
        case medium
        case large
    }
    
//    lazy var townSize: size = {
//        switch population{
//        case 0 ... 10_000:
//            return size.small
//        case 10_001 ... 20_000:
//            return size.medium
//        default:
//            return size.large
//        }
//    }()
     var townSize: size {
        switch population{
        case 0 ... 10_000:
            return size.small
        case 10_001 ... 20_000:
            return size.medium
        default:
            return size.large
        }
    }
    
    
    func description (){
        
        print("We have \(population) population in our town")
        print("We have \(numberOfStopLights) of stop lights")
    
    }
    
    mutating func changePopulation(by amount: Int){
            
        population += amount
            
        
    }
}


