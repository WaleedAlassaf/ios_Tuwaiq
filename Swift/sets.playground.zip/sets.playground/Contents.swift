import Cocoa

//Listing 11.1 Creating a set

//var groceryList = Set<String> (["Apple", "Orange", "Strawberry", "BlackBerry"])

var groceryList: Set = ["Apple", "Orange", "Strawberry", "BlackBerry"]

groceryList.insert("kiwi")

//Listing 11.4 Looping through a set

for food in groceryList {
    
    print(food)
}

//Listing 11.5 Removing an element from a set

groceryList.remove("kiwi")
print(groceryList)

//Listing 11.6 Has bananas?

let has_Apple = groceryList.contains("Apple")
//Listing 11.7 Combining sets
let friends_GroceryList: Set = ["Apple", "orange", "WaterMelon", "Blackberry"]

let sharedList = groceryList.union(friends_GroceryList)
print(sharedList)

//Listing 11.8 Intersecting sets
groceryList.intersection(friends_GroceryList)

//Listing 11.9 Detecting intersections in sets
groceryList.isDisjoint(with: friends_GroceryList)


//XOR
groceryList.symmetricDifference(friends_GroceryList)

//Listing 11.11 Initializing sets using arrays
var Players = ["waleed", "ali", "saleh"]
var winners = ["waleed", "ali"]

var MyPlayerSet = Set(Players)
var MyWinnerSet = Set(winners)

MyPlayerSet.subtract(MyWinnerSet)
