import Cocoa


// bronze challenge + silver challenge

enum shapeDimensions {
    
    case point
    case square (side: Double)
    case rectangle (width: Double, height: Double)
    case trangle (side1: Double, side2: Double, side3: Double)
    
    func perimeter () -> Double{
        
        switch self{
            case let .square(side: Side ):
                return Side + Side + Side + Side
        case let .rectangle(width: w, height: h):
                return w + h + w + h
        
        case let .trangle(side1: S1, side2: S2, side3: S3):
                return S1 + S2 + S3
        
        case .point:
            return 0
        
        }
    }
    }
    
var MySquare = shapeDimensions.square(side: 10.0)
print(MySquare.perimeter())

var myRectangle = shapeDimensions.rectangle(width: 9.6, height: 5.2)
print(myRectangle.perimeter())

var myTrangle = shapeDimensions.trangle(side1: 4, side2: 4, side3: 3)
print(myTrangle.perimeter())
