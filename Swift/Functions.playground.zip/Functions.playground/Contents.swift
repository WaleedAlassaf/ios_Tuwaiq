import Cocoa
//12.1􏰺􏰅􏰏􏰝􏰞􏰝􏰞􏰚 􏰂 􏰏􏰍􏰞􏰣􏰄􏰝􏰎􏰞
func helloworld() {
    
    print("Hello World")
    
}

helloworld()

//12.2

func helloPerson (name: String){
    
    return print("Hello \(name)!")
    
}

helloPerson(name: "Waleed")

//12.3

func functionForDiv (numerator: Double, denominator: Double){
    
    return print("\(numerator) divided by \(denominator) = \(numerator / denominator)")
    
}

functionForDiv(numerator: 9.0, denominator: 3.0)


//12.4

func SendHello (to name: String){
    
    return print("hello \(name)")
}
SendHello(to: "ali")

//12.5 defult parameter

func DoMyMath (num1: Int, num2: Int, Punctuation: String = ".") -> String{
    
    return ("\(num1) * \(num2) = \(num1 * num2) \(Punctuation)")
    
}
//print(DoMyMath(num1: 10, num2: 5))
print(DoMyMath(num1: 10, num2: 5, Punctuation: "!"))


//12.6 changing an outside var needs an "inout" in parameter and & in the calling
var errorMsg = ""
func sendOutSideOfThisFunction (_ code: Int, totheErrorMsg error: inout String) {
    
    if code == 400 {
        
        error += "Error 400"
        
    }
    
}
sendOutSideOfThisFunction(400, totheErrorMsg: &errorMsg)

print(errorMsg)

//12.7
func GiveMeMyNumbersBack (_ num1: Int, _ num2: Int) -> Int{
    
    return (num1 * num2)
    
}

GiveMeMyNumbersBack(10, 2)

//12.9 nested function
func calculate (base: Double, height: Double)-> Double{
    
    let rectangle = base * height
    func devide(a: Double)-> Double{
        return a / 2
    }
    return devide(a: rectangle)
}

calculate(base: 10, height: 3)

//12.10

func sortEvenOdds (number1: [Int]) -> (evens: [Int], odds: [Int]){
    var even = [Int]()
    var odds = [Int]()
    for numbers in number1 {
        
        if numbers % 2 == 0 {
            even.append(numbers)
            
        }else{
            odds.append(numbers)
        }
        
    }
    return (even, odds)
    
}

print(sortEvenOdds(number1: [1,2,3,4,5,6,7,8,9]))


//12.11 using a function inside a variable

var listofnumbers = [82,62,16,97,26,12]
let sortMyNumbers = sortEvenOdds(number1: listofnumbers)


//12.12
//
func greetBymiddleName (fullName name:(first: String, middle: String?, last: String)){
    
    
    guard let middleName = name.middle else {
         print ("hello there !")
        return
    }
    print("hi \(middleName)")
}
greetBymiddleName(fullName: (first: "Waleed", middle: "N", last:"Alassaf"))
