import Cocoa

//Listing 6.1 A for-in loop
var numbers = 0

for i in 1...5{
    
    numbers += 1
    print ("myFirstInt = \(numbers) at iteration \(i)")

}
print("")
//
var numbers2 = 0
// _ means we dont care just do it with anything
for _ in 1...5{
    
    numbers2 += 1
    print ("myFirstInt = \(numbers2)")

}
// where. Listing 6.4 A for-in loop with a where clause

var num = 0

for i in 1...100 where i % 2 == 0{
    
    print ("\(i) is an even number" )
    
}


print ("")


//while loops
var i = 0
while i <= 10 {
    
    print ("hello")
    i += 1
}


// repeat while loop
print ("")
i = 0

repeat {
    print ("repeated")
    i += 1
}
while i <= 10

// Listing 6.6 Using continue

var sheild = 5
var overheat = false
var fireCount = 0
var enemyShip = 0
while sheild > 0 {
    
    if enemyShip == 500 {
        print ("You win!")
        break
        
    }
    // if overheat is true start the code for cool down
    if overheat {
        print ("Overheating ! 5 seconds")
        sleep(5)
        print("ready to fire")
        sleep(1)
        fireCount = 0
        overheat = false
    }
    // if the fire count is 100 flip overheat to true and cut the rest of the code and start again op top of the loop
    if fireCount == 100 {
        overheat = true
        continue
    }
    
    print ("fire!")
    fireCount += 1
    enemyShip += 1
}



