import Cocoa

var arr: [String] = []


enum token: CustomStringConvertible {
    
    case number(Int)
    case plus
    case Minus
    case multiply
    case divide
    
    var description: String {
        switch self{
            case .number(let n):
                arr.append(String(n))
                return "Number: \(n)"
                
            case .plus:
                return "Symbol: +"
            case .Minus:
                return "Symbol: -"
            case .multiply:
                return "Symbol: *"
            case .divide:
                return "Sumbol: /"
        }
    }
}

class Lexer {
    enum Error: Swift.Error {
        case InvalidChar(Character)
    }
    
    let input: String
    var position: String.Index
    
    init(input: String) {
        self.input = input
        self.position = input.startIndex
    }
    func peek() -> Character? {
        guard position < input.endIndex else {
            return nil
        }
        return input[position]
    }
    func advance(){
        assert(position < input.endIndex, "Cant go past end index!")
        position = input.index(after: position)
    }
    
    func getNumber()->Int {
        var value = 0
        while let nextCharacter = peek() {
            switch nextCharacter{
                case "0"..."9":
                    let digitalValue = Int(String(nextCharacter))!
                    value = 10 * value + digitalValue
                    advance()
                default:
                    return value
            }
        }
        return value
        
    }
    func lex() throws -> [token] {
        var tokens = [token]()
        var DivMultTokens = [token]()
        
        while let nextChar = peek() {
            switch nextChar {
                case "0"..."9":
                    let value = getNumber()
                    tokens.append(.number(value))
                case "+":
                    tokens.append(.plus)
                    advance()
                case "-":
                    tokens.append(.Minus)
                    advance()
                case "*":
                    tokens.append(.multiply)
                    advance()
                case "x":
                    tokens.append(.multiply)
                    advance()
                case "/":
                    tokens.append(.divide)
                    advance()
                case " ":
                    advance()
                default:
                    throw Lexer.Error.InvalidChar(nextChar)
            }
        }
        return tokens
    }
}

class Parser {
    
    enum Error: Swift.Error {
        
        case UnexpectedEndOfInput
        case invalidToken(token)
    }
    
    let tokens: [token]
    var position = 0
    
    init(tokens: [token]) {
        self.tokens = tokens
    }
    
    
    func getNextToken() -> token? {
        guard position < tokens.count else {
            return nil
        }
        let token = tokens[position]
        position += 1
        return token
    }
    
    
    func getNumber() throws -> Int{
        
        guard let token = getNextToken() else {
            throw Parser.Error.UnexpectedEndOfInput
        }
        switch token{
            case .number(let value):
                return value
            case .plus:
                throw Parser.Error.invalidToken(token)
            case .Minus:
                throw Parser.Error.invalidToken(token)
            case .multiply:
                throw Parser.Error.invalidToken(token)
            case .divide:
                throw Parser.Error.invalidToken(token)

        }
    }
    
    func parse() throws -> Int{
        
        var value = try getNumber()
        
        while let token = getNextToken(){
            let nextNumber = try getNumber()
            switch token{
                case .plus:
                    value += nextNumber
                case .Minus:
                    value -= nextNumber
                case .multiply:
                    value *= nextNumber
                case .divide:
                    value /= nextNumber
                case .number:
                    throw Parser.Error.invalidToken(token)
            }
        }
        
        return value
    }
}

func evaluate (_ input: String) {
    print("Evaluating \(input)")
    let mylexer = Lexer(input: input)

    do{
        let tokens = try mylexer.lex()
        
        print("Lexer output: \(tokens)")
        
        let parser = Parser(tokens: tokens)
        let result = try parser.parse()
        print("Parse output: \(result)")
        
    }catch Parser.Error.UnexpectedEndOfInput {
        print("Unexpected end of input during parsing")
    }
    // Silver challenge
    catch Parser.Error.invalidToken(let token){
        
        let str = String(describing: token)
        let range: Range<String.Index> = input.range(of: str)!
            let index1: Int = input.distance(from: input.startIndex, to: range.lowerBound)
        print("invalid token during parsing \(token) INDEX: \(index1)")
    }
    
    catch Lexer.Error.InvalidChar(let char){
        let str = String(describing: char)
        let range: Range<String.Index> = input.range(of: str)!
            let index1: Int = input.distance(from: input.startIndex, to: range.lowerBound)
        print("Invalid \(char) INDEX: \(index1)")
    }
    
    catch{
        print("An error occured \(error)")
    }
}


evaluate("10 + 5 + 3")
evaluate("10 + 5 + three")
evaluate("10 + 5 - 3")
evaluate("10 * 3 + 5 * 3")
evaluate("10 + 3 * r + 3")
evaluate("10 + 3 * 2 a 3")


print("Bronze Challenge")
evaluate("10 + 3 + 2 - 3")
