//
//  Zombie.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation

class zombie: Monsters {
    
    var WalkWithLimp = true
    func regenerat(){
        WalkWithLimp = false
        
        
    }
    override func terrorizeTown() {
        town?.changePopulation(by: -10)
        super.terrorizeTown() // we access the method in monster class here
        regenerat()
    }
    
}
