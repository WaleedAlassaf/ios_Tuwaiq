//
//  Monster.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation

class Monsters {
    
    var town: Town?
    var name = "Monster"
    
    func terrorizeTown (){
        //print("test")
        if town != nil {
            
            print("\(name) is terrorizing the town")
            
        }else {
            
            print("\(name) hasn't found any towns")
     
        }
    }
}
