//
//  Town.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation


struct Town {
    var population = 29
    var numberOfStopLights = 4
    

    
    func description (){
        
        print("we have \(population) people left in our town")
    }
    
    mutating func changePopulation(by amount: Int){
            
        population += amount
            
        
    }
}


