//
//  Vampire.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 05/10/2020.
//

import Foundation


class Vampire : Monsters {
    
    
    
    var vampireArr:[Vampire] = []
    
    
    override func terrorizeTown() {
        name = "Vampire"

        super.terrorizeTown()
        if town!.population > 0  {
            town?.changePopulation(by: -1)
            let newVampire = Vampire()
            vampireArr.append(newVampire)
            
        }else {
            print("the population are gone the number of vampires are \(vampireArr.count)")
            
            
            
        }
    }
    


}
