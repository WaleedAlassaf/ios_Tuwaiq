//
//  main.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation

var myTown = Town()
print("population = \(myTown.population) ")



var genericZombie: Monsters = zombie()
genericZombie.town = myTown
genericZombie.terrorizeTown()



if genericZombie.town?.population != nil {

    if genericZombie.town!.population <= 0 {
        genericZombie.town!.population = 0
        print("the population are gone \(genericZombie.town!.population) the zombies took over the town!")
    }else {
        
        genericZombie.town?.description()
        
    }
}

// silver challenge 

var Vampire1 = Vampire()
Vampire1.town = myTown

for _ in 0...30 {
    Vampire1.terrorizeTown()
    Vampire1.town?.description()

}




