//
//  Town.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation


struct Town {
    var population = 5_643
    var numberOfStopLights = 4
    

    
    func description (){
        
        print("We have \(population) population in our town")
        print("We have \(numberOfStopLights) of stop lights")
    
    }
    
    mutating func changePopulation(by amount: Int){
            
        population += amount
            
        
    }
}


