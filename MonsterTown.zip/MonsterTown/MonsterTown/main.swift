//
//  main.swift
//  MonsterTown
//
//  Created by Waleed Alassaf on 04/10/2020.
//

import Foundation

var myTown = Town()
//print("population = \(myTown.population)")
//print("we have \(myTown.numberOfStopLights) stop lights")
var youTwon = myTown
print("my town has \(myTown) population and your town has \(youTwon) ")

print("")
myTown.description()

myTown.changePopulation(by: 1_000)
myTown.description()
//print("population = \(myTown.population)")

//var genericMonster = Monsters()
//genericMonster.town = myTown
//genericMonster.terrorizeTown()
print("")
var genericZombie: Monsters = zombie()
genericZombie.town = myTown
genericZombie.terrorizeTown()
genericZombie.name = "abc"
genericZombie.town?.description()

print("")
var Zombie2 = zombie()
Zombie2.name = "Zombie2"
print("this zombie is called \(Zombie2.name)")
print("\(genericZombie.name)")

print("")
//genericZombie.WalkWithLimp = true
//(genericZombie as? zombie)?.WalkWithLimp = true
print("my town has \(myTown) population and your town has \(youTwon) ")

