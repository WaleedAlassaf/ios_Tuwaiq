//
//  ViewController.swift
//  WorldTrotter
//
//  Created by Waleed Alassaf on 13/10/2020.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        makeGradienColor()
    }
    
    //        let firstFrame = CGRect(x: 160, y: 240, width: 100, height: 150)
    //        let firstView = UIView(frame: firstFrame)
    //        firstView.backgroundColor = #colorLiteral(red: 0.7921232164, green: 0.9557873009, blue: 1, alpha: 1)
    //        view.addSubview(firstView)
    
    //        let SecondFrame = CGRect(x: 20, y: 30, width: 50, height: 50)
    //        let SecondView = UIView(frame: SecondFrame)
    //        SecondView.backgroundColor = #colorLiteral(red: 0.721568644, green: 0.8862745166, blue: 0.5921568871, alpha: 1)
    //        //view.addSubview(SecondView)
    //        firstView.addSubview(SecondView)
    
    
    @IBOutlet weak var UIBackgroundView: UIView!
    
    func makeGradienColor (){
        var gradientLayer = CAGradientLayer()
        gradientLayer.frame = UIBackgroundView.bounds
        
        gradientLayer.colors = [UIColor.purple.cgColor, UIColor.blue.cgColor, UIColor.green.cgColor, UIColor.yellow.cgColor,UIColor.red.cgColor]
        
        UIBackgroundView.layer.addSublayer(gradientLayer)
    }
    
    
}

