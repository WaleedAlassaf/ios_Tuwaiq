import Cocoa

var str = "a"


var Emoji = Array("👨‍👩‍👦‍👦".unicodeScalars)
print(Emoji)
print("\u{0001F466}") // boy emoji
print("\u{0001F467}") // girl emoji
var son_daughter_Emoji = 0
for i in Emoji{
    
    print(i)
    if i == "\u{0001F466}" || i == "\u{0001F467}"{
        son_daughter_Emoji += 1
    }
}

print("\nthere's \(son_daughter_Emoji) boy or girl in this Emoji")
