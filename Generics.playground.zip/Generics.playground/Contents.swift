import Cocoa

struct StackIterator<T>: IteratorProtocol {
    
    //typealias Element = T
    
    var stack: Stack<T>
    
    mutating func next() -> T? {
        return stack.pop()
    }
}


struct Stack<Element>: Sequence {
    
    var items = [Element]()
    mutating func push(_ NewItem: Element){
        items.append(NewItem)
    }
    
    
    mutating func pop()-> Element? {
        guard !items.isEmpty else {return nil}
        return items.removeLast()
    }
    
    func map<U>(_ txform: (Element) -> U) -> Stack<U>{
        var mappedItems = [U]()
        for item in items{
            mappedItems.append(txform(item))
        }
        return Stack<U>(items: mappedItems)
    }
    
    func makeIterator() -> StackIterator<Element> {
        return StackIterator(stack: self)
    }
    
    mutating func pushAll(_ array: [Element]){
        
        for item in array {
            self.push(item)
        }
        
    }
}

var IntStack = Stack<Int>()

IntStack.push(1)
IntStack.push(2)
var DoubleStack = IntStack.map{ 2 * $0 }
print(String(describing: IntStack.pop()))
print(String(describing: IntStack.pop()))
print(String(describing: IntStack.pop()))


//var int1 = (1,3)
//print(String(describing: int1))

var StringStack = Stack<String>()

StringStack.push("Hello world")
StringStack.push("How are you?")
print(String(describing: StringStack.pop()))
print(String(describing: StringStack.pop()))
print(String(describing: StringStack.pop()))


func myMap<T, U>(_ items: [T], _ txform: (T) -> (U)) -> [U] {
    
    var result = [U]()
    for item in items{
        result.append(txform(item))
        
    }
    return result
}

let Strings = ["one", "two", "three"]
let stringLength = myMap(Strings) {$0.count}
print(stringLength)


print(String(describing: DoubleStack.pop()))
print(String(describing: DoubleStack.pop()))


func checkIfEqual<T: Equatable> (_ first: T, _ second: T) -> Bool {
    
    return first == second
}
print(checkIfEqual(1, 1))
print(checkIfEqual("a String", "a String"))
print(checkIfEqual("a String", "another String"))
//print(checkIfEqual(IntStack, DoubleStack))



func CheckDescriptionMatch <T: CustomStringConvertible, U: CustomStringConvertible>(_ first: T, _ second: U) -> Bool{
    
    return first.description == second.description
}

print(CheckDescriptionMatch(Int(1), UInt(1)))
print(CheckDescriptionMatch(1, 1.0))
print(CheckDescriptionMatch(Float(1.0), Double(1.0) ))


protocol IteratorProtocol {
    
    associatedtype Element
    mutating func next() -> Element?
    
    
}



var myStack = Stack<Int>()
myStack.push(10)
myStack.push(20)
myStack.push(30)
var myStackIterator = StackIterator(stack: myStack)
while let value = myStackIterator.next(){

print("Go \(value)")
}

//for value in myStack {
//    print("for-in loop got \(value)")
//}
//For-in loop requires 'Stack<Int>' to conform to 'Sequence'.
//I'm not sure why its saying that.




myStack.pushAll([1,2,3])
for value in myStack {
    
    
    print("after pushing: got \(value)")
}
