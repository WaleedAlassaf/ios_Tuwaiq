import Cocoa



//􏰸􏰏􏰚􏰄􏰏􏰖􏰝􏰂􏰆􏰏􏰅􏰋􏰸􏰏􏰚􏰄􏰏􏰖􏰝􏰂􏰆􏰏􏰅􏰋􏰸􏰏􏰚􏰄􏰏􏰖􏰝􏰂􏰆􏰏􏰅􏰋􏰸􏰏􏰚􏰄􏰏􏰖􏰝􏰂􏰆􏰏􏰅􏰋􏰛􏰏􏰚􏰄􏰏􏰖􏰝􏰂􏰆􏰘􏰛􏰏􏰚􏰄􏰏􏰖􏰝􏰂􏰆􏰘dictionary silver challenge

var players1 = ["waleed", "ahmed", "ali"]
var players2 = ["safanh", "nourah", "aliya"]
var players3 = ["a", "b", "c"]
var teams :[String : [String]] = ["TeamOne" : players1,  "TeamTwo" : players2, "TeamABC" : players3]

//print("The Team one has player: \(teams["TeamOne"]!)")


//dictionary Gold Challenge

print(teams)

for team in teams.keys {
    print("\(team) members :" )
    
        if team == "TeamOne"{
            
            for P in 0 ..< players1.count {
                print(players1[P])
            }
            print("")
        }else if team == "TeamTwo"{
            
            for P in 0 ..< players2.count {
                print(players2[P])
            }
            print("")
        }
        else {
            for P in 0 ..< players3.count {
                print(players3[P])
            }
            print("")
        }

}
