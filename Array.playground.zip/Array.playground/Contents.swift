import Cocoa

//Listing 8.1 Creating an array
//Listing 8.2 Changing the syntax

var myArray: Array <String>
var mySecondArray: [String] = ["1"]

//Listing 8.3 Initializing the array

myArray = ["Hello", "HI"]

print(myArray)

//Listing 8.5 Using type inference

var my3Array = ["first", "second", "third"]

//note: You cant append to an array if the array is empty
myArray.append("second Array")

//Listing 8.7 So many ambitions!
mySecondArray.append("2")
mySecondArray.append("3")
mySecondArray.append("4")
mySecondArray.append("5")

//Listing 8.9 Removing an item from the array
mySecondArray.remove(at: 2) // remove 3
print(mySecondArray)

//Listing 8.10 Subscripting to find your top three items

print(mySecondArray[...1])

//Listing 8.11 Subscripting to append new information


myArray[1] += "hello world" // this will add the string to the array at the index "[1]"
print (myArray)

//Listing 8.12 Replacing an array item

myArray[1] = "goodbye" //replace the string at index 1
print (myArray)

//Listing 8.13 Inserting a new ambition

my3Array.insert("abcdefg", at: 1)

//Listing 8.14 Using a loop to append items from one array to another

var names = ["ahmed", "ali", "saleh", "khaled"]
var insert_names_array = ["names: "]
for i in names{
    
    insert_names_array.append(i)
    
}
print (insert_names_array)

//Listing 8.15 Refactoring with the addition and assignment operator

var city_names = ["alriyadh", "arras", "abha"]
insert_names_array += city_names
print (insert_names_array)

//Listing 8.16 Checking two arrays for equality
//Listing 8.17 Fixing anotherList

var check_array1 = [1,2,3,4]
var check_array2 = [1,2,3,4]

check_array1 == check_array2

//Listing 8.18 An immutable array
// this array cant be changed
let lunch = [
    
    "burger",
    "rice",
    "chicken"
    
]
