import Cocoa

//Chapter 1: bronze challenge

var str = "Hello world"
print(str)

//Chapter 2: bronze challenge
let numberOfStoplights: Int = 4
var population: Int = 10000
var new_People = 200
let twonname: String = "Albadaya"

let description = "Our town is called \(twonname) and it has a population of \(population), We have build \(numberOfStoplights) Stop lights so far and we've \(new_People) new people chose to live here this year"
print (description)


//chapter 3: Bronze Challenge
if population > 10000{
    print("\(population) is too large ")
    
}
else if population < 10000{
    print ("\(population) is small ")
    
    
}

//Chapter 4: bronze challenge

var num: UInt8 = 0
let z:UInt8 = num &- 1
print (z)
